# Roadmap

## Version 1.0

- [x] Create basic Java CLI app
- [x] Add password strength scoring
- [x] Add suggestions for improvement
- [x] Add README documentation
- [x] Add unit tests

## Version 1.1

- [ ] Improve scoring logic
- [ ] Add entropy-style estimate
- [ ] Add larger common-password list support
- [ ] Improve terminal output formatting

## Version 1.2

- [ ] Add configuration file support
- [ ] Add more unit tests
- [ ] Add GitHub Actions for automated tests

## Future Ideas

- [ ] Build a Java Swing GUI version
- [ ] Build a web version with HTML, CSS, and JavaScript
- [ ] Add educational notes about password security
- [ ] Add OWASP-style security documentation
