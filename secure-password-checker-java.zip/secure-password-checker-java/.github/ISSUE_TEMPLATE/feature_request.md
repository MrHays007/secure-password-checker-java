---
name: Feature request
about: Suggest an improvement or new feature
title: "[Feature] "
labels: enhancement
assignees: ""
---

## Feature summary

What should be added?

## Why this matters

Explain the benefit of the feature.

## Possible implementation

Describe a possible approach if you have one.

## Additional context

Add screenshots, examples, or references if useful.
